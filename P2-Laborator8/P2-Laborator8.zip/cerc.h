#include "dreapta.h"

class CCerc:public CPunct
{
private:
	double raza;
public:
	void citire();
	void perimetru();
};

