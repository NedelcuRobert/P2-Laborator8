#include "dreptunghi.h"

class CPatrat:public CPunct
{
private:
	double latura;
public:
	void citire();
	void perimetru();
};

