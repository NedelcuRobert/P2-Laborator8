#include "punct.h"

void CPunct::citire() {
	cout << "Introduceti coordontele:";
	cin >> x_coord >> y_coord;
}

void CPunct::perimetru() {
	cout << "Clasa de baza punct";
}

