#include "punct.h"

class CDreapta:public CPunct
{
private:
	CPunct p1;
	CPunct p2;
public:
	void citire();
};

