#include <iostream>

using namespace std;

class CPunct
{
protected:
	double x_coord, y_coord;
public:
	virtual void citire();
	virtual void perimetru();
};

