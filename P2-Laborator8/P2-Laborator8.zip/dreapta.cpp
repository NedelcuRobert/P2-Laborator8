#include "dreapta.h"

void CDreapta::citire() {
	cout << "Primul punct" << endl;
	p1.citire();
	cout << "Al doilea punct" << endl;
	p2.citire();
}
