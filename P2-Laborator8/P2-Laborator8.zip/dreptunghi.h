#include "cerc.h"

class CDreptunghi:public CPunct
{
private:
	double lungime;
	double latime;
public:
	void citire();
	void perimetru();
};

